#include 
#include <stdio.h>
#include <stdlib.h>

struct Queue {
	int cacity;
	float *data;
	int first;
	int last;
	int itens; 
};

void createQueue( struct Queue *f, int c ) { 

	f->cacity = c;
	f->data = (float*) malloc (f->cacity * sizeof(float));
	f->first = 0;
	f->last = -1;
	f->itens = 0; 

}

void insert(struct Queue *f, int v) {

	if(f->last == f->cacity-1)
		f->last = -1;

	f->last++;
	f->data[f->last] = v; // incrementa last e insere
	f->itens++; // mais um item inserido

}

int remove( struct Queue *f ) { // pega o item do comeco da fila

	int temp = f->data[f->first++]; // pega o value e incrementa o primeiro

	if(f->first == f->cacity)
		f->first = 0;

	f->itens--;  // um item retirado
	return temp;

}

int empty( struct Queue *f ) { // retorna verdadeiro se a fila esta vazia

	return (f->itens==0);

}

int full( struct Queue *f ) { // retorna verdadeiro se a fila esta cheia

	return (f->itens == f->cacity);
}

void showQueue(struct Queue *f){

	int cont, i;

	for ( cont=0, i= f->first; cont < f->itens; cont++){

		printf("%.2f\t",f->data[i++]);

		if (i == f->cacity)
			i=0;

	}
	printf("\n\n");

}

void main () {

	int option, ca;
	float value;
	struct Queue oneQueue;

	// cria a fila
	printf("\nCapacidade da fila? ");
	scanf("%d",&ca);
	createQueue(&oneQueue, ca);

	// apresenta menu
	while( 1 ){

		printf("\n1 - Inserir elemento\n2 - Remover elemento\n3 - Mostrar Fila\n0 - Sair\n\option? ");
		scanf("%d", &option);

		switch(option){

			case 0: exit(0);

			case 1: // insere elemento
				if (full(&oneQueue)){

					printf("\nFila Cheia!!!\n\n");

				}
				else {

					printf("\nValor do elemento a ser inserido? ");
					scanf("%f", &value);
					insert(&oneQueue,value);

				}

				break;

			case 2: // remove elemento
				if (empty(&oneQueue)){

					printf("\nFila vazia!!!\n\n");

				}
				else {

					value = remove(&oneQueue);
					printf("\n%1f removido com sucesso\n\n", value) ; 

				}
				break;

				case 3: // mostrar fila
					if (empty(&oneQueue)){

						printf("\nFila vazia!!!\n\n");

					}
					else {

						printf("\nConteudo da fila => ");
						showQueue(&oneQueue);

					}
					break;

				default:
					printf("\nOpcao Invalida\n\n");

		}
	}
}