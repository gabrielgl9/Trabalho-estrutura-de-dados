#ifndef NAVEGACAO_H_INCLUDED
#define NAVEGACAO_H_INCLUDED

// Inicializa struct navegacao
typedef struct navegacao {
  char pagina[255]; // URL
  int index; // index da pagina
  struct navegacao* navegacao;
} Navegacao;

// Inicializa a navegação
Navegacao* criarNavegacao();

// Adiciona uma nova navegação
void avancarPagina(Navegacao* navegacao, char novaPagina[]);

// Remove a ultima navegação
void voltarPagina();

// Mostra todas as páginas acessadas
void mostrarNavegacoes(Navegacao* navegacao);

#endif
