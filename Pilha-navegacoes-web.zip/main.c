#include <stdio.h>
#include <stdlib.h>
#include "Navegacao.h"

int main(void) {
  
  // Abre o Google Chrome
  Navegacao* navegacao = criarNavegacao();
  
  // Pesquisa o bug que deu no codigo
  avancarPagina(navegacao, "https://www.google.com/search?client=firefox-b-d&q=strcpy+incompatible+integer+to+pointer+conversion+pointer+char");

  // Entra na pagina do stack overflow
  avancarPagina(navegacao, "https://stackoverflow.com/questions/31653813/incompatible-integer-to-pointer-conversion");

  // Não encontra solução do bug e volta para a pesquisa do google
  voltarPagina(navegacao);
  
  // Entra na pagina de um site aleatorio
  avancarPagina(navegacao, "https://cboard.cprogramming.com/c-programming/149256-warning-incompatible-integer-pointer-conversion-assigning-char-*-int.html");

  // Descobre o bug e mostra as navegacoes
  mostrarNavegacoes(navegacao);
  return 0;
}