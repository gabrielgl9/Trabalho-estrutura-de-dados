#include <stdio.h>
#include <stdlib.h>
#include <string.h> //necessário para strcpy
#include "Navegacao.h"

Navegacao* criarNavegacao()
{
    Navegacao *navegacao = (Navegacao*) malloc(sizeof(Navegacao));
    strcpy(navegacao->pagina, "http://google.com");
    navegacao->index = 1;
    navegacao->navegacao = NULL;

    return navegacao;
}

void avancarPagina(Navegacao *navegacao, char novaPagina[])
{
    // Busca a ultima navegacao
    Navegacao* atual = navegacao;
    while( atual->navegacao != NULL){
        atual = atual->navegacao;
    }

    // Cria a nova navegacao
    Navegacao* novaNavegacao = criarNavegacao();
    strcpy(novaNavegacao->pagina, novaPagina);
    novaNavegacao->index = atual->index + 1;
    novaNavegacao->navegacao = NULL;

    // Adiciona a nova navegação no fim da pilha de navegacoes
    atual->navegacao = novaNavegacao;
}

void voltarPagina(Navegacao *navegacao)
{
    Navegacao *atual = navegacao;

    // Verifica se a pilha possui mais de uma navegacao
    if (atual->navegacao == NULL) {
      free(atual);
      return;
    }

    // Busca a ultima navegacao
    while( atual->navegacao->navegacao != NULL){
        atual = atual->navegacao;
    }

    // Remove a navegacao da pilha
    free(atual->navegacao);
    atual->navegacao = NULL;
}

void mostrarNavegacoes(Navegacao *navegacao)
{
    Navegacao* atual = navegacao;

    if (atual != NULL) printf("Registro de navegacoes: \n");

    while (atual != NULL) {
        printf("pagina %d: %s\n", atual->index, atual->pagina);
        atual = atual->navegacao;
    }
}

