#include <stdio.h>
#include <stdlib.h>
#include "Impressora.h"

int main(void) {

  // Inicia a Impressora
  Impressao* impressao = criarImpressao();
  
  // Solicita a impressao do documento de RG 
  adicionarNovoDocumento(impressao, "RG");

  // Solicita a impressao do documento de Comprovante de residencia 
  adicionarNovoDocumento(impressao, "Comprovante de residencia");

  // Solicita a impressao do documento de titulo de eleitor 
  adicionarNovoDocumento(impressao, "Titulo de eleitor");

  // Exibe a fila de documentos
  mostrarDocumentos(impressao);

  // Retira um documento ja impresso
  removerDocumentoImpresso(impressao);

  // Retira um documento ja impresso
  removerDocumentoImpresso(impressao);

  // Exibe a fila de documentos
  mostrarDocumentos(impressao);

  // Solicita a impressao do documento de CNH
  adicionarNovoDocumento(impressao, "CNH");

  // Exibe a fila de documentos
  mostrarDocumentos(impressao);

  return 0;
}