#include <stdio.h>
#include <stdlib.h>
#include <string.h> //necessário para strcpy
#include "Impressora.h"

/**
* Cria uma impressao
*
**/
Impressao* criarImpressao()
{
    Impressao *impressao = NULL;
    impressao = (Impressao*) malloc(sizeof(Impressao));

    return impressao;
}

/** 
* Adicionar um novo documento na fila de impressões
*
**/
void adicionarNovoDocumento(Impressao *impressao, char novoDocumento[])
{
    printf("imprimindo novo documento...\n");
  
    // Busca o ultimo documento da fila
    Impressao* atual = impressao;
    while( atual->proxImprimir != NULL){
        atual = atual->proxImprimir;
    }

    // Caso seja o primeiro documento
    if (!strlen(atual->documento)) {
      strcpy(atual->documento, novoDocumento);
      return;
    }

    // Cria o registro do novo documento para ser impresso
    Impressao* novaImpressao = criarImpressao();
    strcpy(novaImpressao->documento, novoDocumento);
    novaImpressao->proxImprimir = NULL;

    // Adiciona no fim da fila
    atual->proxImprimir = novaImpressao;
}

/**
* Retira o primeiro documento impresso
*
**/
void removerDocumentoImpresso(Impressao* impressao)
{
    if (impressao->proxImprimir == NULL) {
      printf("Nao ha mais documentos para imprimir");
    }
    printf("retirando documento...\n");
    Impressao *tmp = impressao->proxImprimir;
    impressao->proxImprimir = tmp->proxImprimir;
}

/**
* Mostra toda a fila de documentos
*
*/
void mostrarDocumentos(Impressao *impressao)
{
    Impressao *atual = impressao;

    if (atual != NULL) printf("Registro de impressoes: \n");

    while (atual != NULL) {
        printf("Documento: %s\n", atual->documento);
        atual = atual->proxImprimir;
    }
}

