#ifndef IMPRESSORA_H_INCLUDED
#define IMPRESSORA_H_INCLUDED

// Inicializa struct impressao
typedef struct impressao {
  char documento[255]; // Documento
  struct impressao* proxImprimir;
} Impressao;

// Inicializa a impressao
Impressao* criarImpressao();

// Adiciona um novo documento para impressao
void adicionarNovoDocumento(Impressao* impressao, char novoDocumento[]);

// Remove o primeiro documento impresso da impressora
void removerDocumentoImpresso(Impressao* impressao);

// Mostra todos os documentos a serem impressos
void mostrarDocumentos(Impressao* impressao);

#endif
