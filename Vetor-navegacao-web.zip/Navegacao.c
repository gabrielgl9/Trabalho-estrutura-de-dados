#include <stdio.h>
#include <stdlib.h>
#include <string.h> //necessário para strcpy e stlen
#include "Navegacao.h"

Navegacao* criarNavegacao()
{
    Navegacao *navegacao = (Navegacao*)malloc(sizeof(Navegacao));
    
    strcpy(navegacao[0], "http://google.com");

    return navegacao;
}

void avancarPagina(Navegacao *navegacao, int size, char novaPagina[])
{
    navegacao = realloc (navegacao, (size + 1) * sizeof (Navegacao));
    
    strcpy(navegacao[size], novaPagina);
}

void voltarPagina(Navegacao *navegacao, int size)
{
    navegacao = realloc(navegacao, (size) * sizeof (Navegacao));

    strcpy(navegacao[size - 1], "");
}

int buscarTopo(Navegacao *navegacao)
{
  int aux = 1;
  int contPosicao = 0;
  while (aux) {
    if (strlen(navegacao[contPosicao])) {
      contPosicao++;
    } else {
      aux = 0;
    }
  }
  return contPosicao;
}

void mostrarNavegacoes(Navegacao *navegacao, int size)
{
    int i = 0;
    printf("Registro de navegacoes: \n\n");
    for (i = 0; i < size; i++) {
      if (strlen(navegacao[i])) {
        printf("%d: %s\n\n", i+1, navegacao[i]);
      }
    }
}

