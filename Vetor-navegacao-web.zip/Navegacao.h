#ifndef NAVEGACAO_H_INCLUDED
#define NAVEGACAO_H_INCLUDED

typedef char Navegacao[255];

// Inicializa a navegação
Navegacao* criarNavegacao();

// Adiciona uma nova navegação
void avancarPagina(Navegacao *navegacao, int size, char novaPagina[]);

// Remove a ultima navegação
void voltarPagina(Navegacao *navegacao, int size);

// Mostra todas as páginas acessadas
void mostrarNavegacoes(Navegacao *navegacao, int size);

// Busca o topo da "pilha" 
int buscarTopo(Navegacao *navegacao);

#endif
